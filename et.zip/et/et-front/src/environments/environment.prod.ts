export const environment = {
  production: true,
  // setting environment variabls
  siteName: 'Economy Trucking',
  apiUrl: 'https://et-api-uat.herokuapp.com/api/v1/'
};
