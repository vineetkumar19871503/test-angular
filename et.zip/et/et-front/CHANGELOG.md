# [Apex - Angular 5+ Bootstrap Admin Template]


### Changelog
***

#### `1.0` (2017-10-24)
***

Initial release

#### `2.0` (2017-11-10)
***
Added
----------
Taskboard
Audio Player
Video Player
Chat - Audio & Video
Drag n Drop
Tour


Updated
--------
Updated to Angular 5+
Updated starter kit to Angular 5+
Documentation
Calendar
Sweet Alert
Data Tables
Quill Editor


Fixed
--------
Minor Bugs & design flaws


#### `2.1` (2017-11-21)
***
Added
----------
Search Page
FAQ Page
Knowledge Base Page
Internationalization (i18n) Support
Authentication Service


Updated
--------
Angular Version (5.0.2)
starter kit
Documentation
Calendar
Inbox
Chat
NGX Datatable
NGX Charts

Fixed
--------
Minor Bugs & design flaws