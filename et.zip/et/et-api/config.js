var config = {
  jwtTokenExpires: 2,
  expressSessionSecure: true,
  expressSessionHttpOnly: false,
  db: {
    url: 'mongodb://vineetkumar1987:Vineetkumar1987#@ds031581.mlab.com:31581/etrucking'
    // url: 'mongodb://vineetkumar1987:Vineetkumar1987#@ds127300.mlab.com:27300/etruckinglocal'
    // url: 'mongodb://Economy:economy1@etrucking-shard-00-00-bwnlo.mongodb.net:27017,etrucking-shard-00-01-bwnlo.mongodb.net:27017,etrucking-shard-00-02-bwnlo.mongodb.net:27017/etrucking?ssl=true&replicaSet=ETrucking-shard-0&authSource=admin'  // <---- local
    // url: 'mongodb://127.0.0.1:27017/etrucking'  // <---- local
  // url:'mongodb://vineetkumar1987:Vineetkumar1987#@ds163418.mlab.com:63418/etrucking_staging'
   
  },
  nexmo: {
    apiKey: '8a7e8063',
    apiSecret: 'bda5f5e1f458cd7d'
  },
  marital_status: ['single', 'married', 'divorcee', 'widowed'],
  apiPrefix: '/api/v1',
  mobApiPrefix: '/api/v1.0',
  users: {
    admin: { password: 'password' }
  },
  bcryptSalt: 10,
  jwtSecret: '09sdufa0sfusafkljsa098',
  host: 'localhost',
  port: process.env.PORT || 3005,
  enableAuth: true,
  enableCheckPermissions: true
}
if (process.env.NODE_ENV != undefined && process.env.NODE_ENV == 'dev') {
  config.expressSessionSecure = false;
  config.expressSessionHttpOnly = true;
}
module.exports = config; 
