
const { isDev } = require('./src/globals/methods');
const { port, apiPrefix, mobApiPrefix } = require('./config');
const config = require('./config');
const express = require('express'),
  app = express(),
  bodyParser = require('body-parser'),
  // expCtrl = require('express-controllers-routes'),
  expCtrl = require('./src/utilities/routes-generator'),
  Nexmo = require('nexmo'),
  restResponse = require('express-rest-response'),
  session = require('express-session');

app.use(require('cors')());

//express-rest-response middleware configuration  
app.use(restResponse({
  showStatusCode: true,
  showDefaultMessage: true
}));

// configuring nexmo plugin
const nexmoObj = new Nexmo({
  apiKey: config.nexmo.apiKey,
  apiSecret: config.nexmo.apiSecret
});

// adding nexmo object to request using middleware
app.use(function (req, res, next) {
  req.nexmo = nexmoObj;
  next();
})

/*
For upload file
*/
var multer = require('multer');
var multerS3 = require('multer-s3');
var aws = require('aws-sdk');

aws.config.update({
  secretAccessKey: 'JS/XqMiud4K8oXm/5Ea5wCpznR6+fxbon9OYUBuZ',
  accessKeyId: 'AKIAJDI2IXXPMN4EVTHA',
  region: 'us-west-1'
});

s3 = new aws.S3();

var upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'sbdevents',
    key: function (req, file, cb) {
      var fullPath = 'uploads/et/' + Date.now() + '_' + file.originalname;
      cb(null, fullPath); //use Date.now() for unique file keys
    }
  })
});

app.post('/api/v1/upload', upload.any(), function (req, res, next) {
  res.send({ 'mimetype': req.files[0].mimetype, 'file_path': req.files[0].location });
});
//Ends here

//using express-session middleware
app.use(session({
  cookie: {
    httpOnly: config.expressSessionHttpOnly,
    path: '/',
    maxAge: (7 * 24 * 60 * 60 * 1000), //expires 7 days
    secure: config.expressSessionSecure,
  },
  resave: false,
  saveUninitialized: true,
  secret: '98safhsaf98safklnf'
}));



//using body-parser middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));




//use cors for Access-Control-Allow-Origin' issue
// if (isDev) {
// app.use(require('cors')());
// }

//check auth and roles using middleware
app.use(require('./src/auth/checkPermissions'));

//defining and using routers
const router = express.Router();
expCtrl.bind(router, __dirname + '/src/controllers/', apiPrefix); // For Api Routing
expCtrl.bind(router, __dirname + '/src/mob-apis/', mobApiPrefix); // For Mobile Api Routing
app.use(router);


//capture all 404 urls
app.use(function (req, res, next) {
  // respond with json
  if (req.accepts('json')) {
    res.rest.notFound();
    return;
  }
  // default to plain-text. send()
  res.type('txt').send('Not found');
});

//connecting database
require('./src/db/connect')();

app.listen(port, () => {
  console.log('Express App listening on port:', port);
});