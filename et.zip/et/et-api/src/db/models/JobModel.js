const ObjectId = require('mongoose').Types.ObjectId,
    jobModel = require('../../db/schemas/JobSchema').models.jobModel,
    subJobModel = require('../../db/schemas/JobSchema').models.subJobModel,
    { addZeroes } = require('../components/counter');
module.exports = {
    getJobs: function (conditions = {}, fields = {}, order = { 'test': -1 }, limit = 0) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: '_id',
                        foreignField: 'j_id',
                        as: 'sub_jobs'
                    }
                },
                { $unwind: '$customer' },
                { $match: conditions }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            if (limit > 0) {
                query.push({ $limit: limit });
            }
            jobModel.aggregate(query)
                .exec(function (err, jobs) {
                    err ? reject(err) : resolve(jobs);
                });
        });

    },
    jobListByCustomerid: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: '_id',
                        foreignField: 'j_id',
                        as: 'sub_jobs'
                    }
                },
                { $unwind: '$customer' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            jobModel.aggregate(query)
                .exec(function (err, jobs) {
                    err ? reject(err) : resolve(jobs);
                });
        });

    },
    getSubJobs: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'jobs',
                        localField: 'j_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$customer' },
                { $unwind: '$job' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            subJobModel.aggregate(query)
                .exec(function (err, jobs) {
                    err ? reject(err) : resolve(jobs);
                });
        });
    },
    AllSubJobById: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'jobs',
                        localField: 'j_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$customer' },
                { $unwind: '$job' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            subJobModel.aggregate(query)
                .exec(function (err, jobs) {
                    err ? reject(err) : resolve(jobs);
                });
        });
    },
    SubJobById: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'jobs',
                        localField: 'j_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$customer' },
                { $unwind: '$job' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            subJobModel.aggregate(query)
                .exec(function (err, jobs) {
                    err ? reject(err) : resolve(jobs);
                });
        });
    },
    // saves job or sub job. data is to be saved and type will be either 'j' (job) or 's' (subjob)
    saveJob: function (data, type = 'j') {
        const self = this;
        return new Promise(function (resolve, reject) {
            self._getNextId(data, type, function (nextId) {
                var jModel = jobModel;
                if (type == 'j') {
                    data.job_id = nextId;
                } else {
                    jModel = subJobModel;
                    data.subjob_id = nextId;
                }
                jModel.insertMany(data, function (err, job) {
                    err ? reject(err) : resolve(job);
                });
            });
        });
    },

    saveSubJob: function (data, type = 'j') {
        const self = this;
        return new Promise(function (resolve, reject) {
            self._getNextId(data, type, function (nextId) {
                var jModel = jobModel;
                if (type == 'j') {
                    data.job_id = nextId;
                } else {
                    jModel = subJobModel;
                    data.subjob_id = nextId;
                }
                jModel.insertMany(data, function (err, job) {
                    err ? reject(err) : resolve(job);
                });
            });
        });
    },
    // convert the quote to job
    convertToJob(data) {
        const self = this;
        return new Promise(function (resolve, reject) {
            self.saveJob(data, 'j')
                .then(function (job) {
                    job = job[0];
                    data.j_id = job._id;
                    data.pjob_id = job.job_id;
                    self.saveJob(data, 's')
                        .then(function (subjob) {
                            // update quote status
                            require('./QuoteModel').update({ '_id': data.qt_id }, { 'converted': true })
                                .then(function () {
                                    resolve();
                                })
                                .catch(function () {
                                    reject('Could not convert the quote!' + err.message);
                                });
                        })
                        .catch(function () {
                            self.removeJob({ '_id': job._id });
                            reject('Could not convert the quote!' + err.message);
                        })
                })
                .catch(function (err) {
                    reject('Could not convert the quote!' + err.message);
                });
        });
    },

    removeJob: function (conditions, type) {
        return new Promise(function (resolve, reject) {
            var jModel = type == 'j' ? jobModel : subJobModel;
            jModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        })
    },

    // updates job or sub job. conditions will be matched and type will be either 'j' (job) or 's' (subjob)
    updateJob: function (conditions, data, type = 'j', upsert = true) {
        const model = type == 'j' ? jobModel : subJobModel;
        return new Promise(function (resolve, reject) {
            model.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },

    // get next id for job/subjob (eg: 0001, 0002 ...)
    _getNextId(data, type, cb) {
        const self = this,
            conditions = { 'c_id': ObjectId(data.c_id) };
        if (type != 'j') {
            conditions['j_id'] = ObjectId(data.j_id);
        }
        self.getSubJobs(conditions, {}, { _id: -1 })
            .then(function (subJobs) {
                let nextId = type == 'j' ? addZeroes('job_id', 1) : addZeroes('subjob_id', 1);
                if (subJobs.length) {
                    const subJob = subJobs[0];
                    if (type == 'j') {
                        nextId = addZeroes('job_id', parseInt(subJob.job.job_id) + 1);
                    } else {
                        nextId = addZeroes('subjob_id', parseInt(subJob.subjob_id) + 1);
                    }
                }
                cb(nextId);
            });
    },
    getAllJobsCountByCustomer: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'quotes',
                        localField: '_id',
                        foreignField: 'c_id',
                        as: 'quote'
                    }
                },
                { $unwind: '$quote' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: null,
                        'quotes_count': { $sum: 1 },
                        'c_id': { $first: '$_id' },
                        'customer_id': { $first: '$customer_id' },
                        'cust_name': { $first: '$cust_name' },
                        'cust_role': { $first: '$cust_role' },
                        'org_name': { $first: '$org_name' }
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            require('../../db/schemas/CustomerSchema').models.customersModel.aggregate(query)
                .exec(function (err, quotesCount) {
                    err ? resolve(err) : resolve(quotesCount);
                });
        });
    },
    updateSubJob: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            const subJobLogs = Object.assign({}, data.subjob_logs);
            delete data.subjob_logs;
            subJobModel.update(conditions,
                {
                    $set: data,
                    $push: { 'subjob_logs': subJobLogs }
                },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    }
}