const bcrypt = require('bcrypt'),
    config = require('../../../config'),
    userSchema = require('../../db/schemas/UserSchema'),
    userModel = userSchema.models.userModel;

module.exports = {
    getUsers: function (conditions = {}, fields = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'roles',
                        localField: 'role_id',
                        foreignField: '_id',
                        as: 'role'
                    }
                },
                {
                    $lookup: {
                        from: 'permission_modules',
                        localField: 'role.permissions.permission_module_id',
                        foreignField: '_id',
                        as: 'permission_modules'
                    }
                },
                { $unwind: '$role' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            userModel.aggregate(query)
                .exec(function (err, users) {
                    err ? reject(err) : resolve(self._formatUserData(users));
                });

        });

    },
    saveUser: function (data) {
        var newUser = new userModel(data);
        newUser.password = bcrypt.hashSync(data.password, config.bcryptSalt);
        return new Promise(function (resolve, reject) {
            newUser.save(function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    },

    _formatUserData: function (users) {
        var resUsers = [];
        users.forEach(function (user, i) {
            resUsers[i] = JSON.parse(JSON.stringify(user));
            delete resUsers[i].role_id;
            if (resUsers[i].role.permissions) {
                var permissionModules = resUsers[i].permission_modules,
                    permissions = resUsers[i].role.permissions.map(function (rp, rpi) {
                        var permission = rp;
                        permissionModules[rpi]['module_id'] = permissionModules[rpi]._id;
                        delete permissionModules[rpi]._id;
                        permissionModules[rpi]['module'] = permissionModules[rpi].name;
                        delete permissionModules[rpi].name;
                        permission = Object.assign({}, permission, permissionModules[rpi]);
                        delete permission.permission_module_id;
                        return permission;
                    });
                delete resUsers[i].role.permissions;
                resUsers[i].role['permissions'] = permissions;
            }
            delete resUsers[i].permission_modules;
        });
        if (!resUsers.length) {
            resUsers = [];
        }
        return resUsers;
    }

    // getUserDetails_old: function (conditions) {
    //     const self = this;
    //     if (typeof fields == 'string') {
    //         fields = fields.split(' ');
    //     }
    //     return new Promise(function (resolve, reject) {
    //         userModel.find(conditions)
    //             .populate({
    //                 path: 'role_id',
    //                 populate: {
    //                     path: 'permissions.permission_module_id'
    //                 }
    //             })
    //             .exec(function (err, users) {
    //                 err ? reject(err) : resolve(self._formatUserData(users));
    //             });
    //     });

    // },

    // _formatUserData_old: function (users) {
    //     var resUsers = [];
    //     users.forEach(function (user, i) {
    //         resUsers[i] = JSON.parse(JSON.stringify(user));
    //         resUsers[i].role = resUsers[i].role_id;
    //         delete resUsers[i].role_id;
    //         if (resUsers[i].role.permissions) {
    //             var permissions = resUsers[i].role.permissions.map(function (rp, rpi) {
    //                 var permission = rp;
    //                 const permissionModule = permission.permission_module_id;
    //                 permission['module'] = permissionModule.name;
    //                 permission['module_id'] = permissionModule._id;
    //                 delete permission.permission_module_id;
    //                 return permission;
    //             });
    //             delete resUsers[i].role.permissions;
    //             resUsers[i].role['permissions'] = permissions;
    //         }

    //     });
    //     if (!resUsers.length) {
    //         resUsers = [];
    //     }
    //     return resUsers;
    // }
}