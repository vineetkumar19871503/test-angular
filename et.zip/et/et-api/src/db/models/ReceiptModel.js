const receiptModel = require('../../db/schemas/ReceiptSchema').models.receiptModel;
    
module.exports = {

    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            receiptModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    save: function (data) {
        var newReceipt = new receiptModel(data);
        return new Promise(function (resolve, reject) {
            newReceipt.save(function (err, trip) {
                err ? reject(err) : resolve(trip);
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            receiptModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, numAffected, raw) {
                    err ? reject(err) : resolve(raw);
                });
        });
    },
    getReceipts: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = receiptModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, receipts) {
                err ? reject(err) : resolve(receipts);
            });
        });
    }
}