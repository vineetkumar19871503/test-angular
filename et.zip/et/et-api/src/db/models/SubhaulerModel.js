const subhaulerModel = require('../../db/schemas/SubhaulerSchema').models.subhaulerModel;

module.exports = {
    getSubhauler: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = subhaulerModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, quotesWithStatus) {
                err ? reject(err) : resolve(quotesWithStatus);
            });
        });
    }
}
