const driverModel = require('../../db/schemas/DriverSchema').models.driverModel,
    subhaulerModel = require('../../db/schemas/SubhaulerSchema').models.subhaulerModel;

module.exports = {
    save: function (data) {
        var newDriver = new driverModel(data);
        return new Promise(function (resolve, reject) {
            newDriver.save(function (err, driver) {
                err ? reject(err) : resolve(driver);
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true, multi = true) {
        return new Promise(function (resolve, reject) {
            driverModel.update(conditions,
                { $set: data },
                { upsert, multi },
                function (err, numAffected, raw) {
                    err ? reject(err) : resolve(raw);
                });
        });
    },
    getDrivers: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = driverModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, drivers) {
                err ? reject(err) : resolve(drivers);
            });
        });
    },
    // get drivers which are not assigned to any job
    getUnoccupiedDrivers: function (conditions = {}) {
        return new Promise(function (resolve, reject) {
            driverModel.find(conditions, function (err, drivers) {
                err ? reject(err) : resolve(utils.filterDrivers(drivers));
            })
        });
    },
    getSubhaulers: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'truckers',
                        localField: '_id',
                        foreignField: 'subhauler_id',
                        as: 'drivers'
                    }
                },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            subhaulerModel.aggregate(query)
                .exec(function (err, subhaulers) {
                    err ? reject(err) : resolve(subhaulers);
                });
        });
    },
    getUnoccupiedSubhaulers: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'truckers',
                        localField: '_id',
                        foreignField: 'subhauler_id',
                        as: 'drivers'
                    }
                },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            subhaulerModel.aggregate(query)
                .exec(function (err, subhaulers) {
                    err ? reject(err) : resolve(utils.filterSubhaulers(subhaulers, conditions));
                });
        });
    }
}

const utils = {
    filterDrivers: function (drivers) {
        return drivers.filter(function (dr) {
            var timeDiff = Math.abs(new Date().getTime() - dr.assigned_time.getTime());
            timeDiff = Math.ceil(timeDiff / (1000));
            // - if driver is not assigned any job
            // -if driver is assigned a job and its been more than 2 hours since he did not approve the job (no show up case)
            if (!dr.is_assigned || (dr.is_assigned && !dr.job_approved && timeDiff > 7200)) {
                return dr;
            }
        });
    },
    filterSubhaulers: function (subhaulers, conditions) {
        const truckType = conditions['drivers.truck_type'] ? conditions['drivers.truck_type'] : null;
        return subhaulers.filter(function (sh) {
            sh.drivers = sh.drivers.filter(function (dr) {
                // checking the truck type
                if (!truckType || dr.truck_type == truckType) {
                    var timeDiff = Math.abs(new Date().getTime() - dr.assigned_time.getTime());
                    timeDiff = Math.ceil(timeDiff / (1000));
                    // - if driver is not assigned any job
                    // -if driver is assigned a job and its been more than 2 hours since he did not approve the job (no show up case)
                    if (!dr.is_assigned || (dr.is_assigned && !dr.job_approved && timeDiff > 7200)) {
                        return dr;
                    }
                }
            });
            if (sh.drivers.length) {
                return sh;
            }
        });
    }
}
