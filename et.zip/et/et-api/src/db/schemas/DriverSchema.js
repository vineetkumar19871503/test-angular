const { getToday } = require('../../globals/methods'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    drivers: new Schema({
        is_assigned: { type: Boolean, default: false }, // helps to filter the driver in assign job module
        assigned_time: { type: Date, default: Date.now },   // the time when driver was assigned a job last time
        job_approved: { type: Boolean, default: false },    // set to true/false if driver approved the job or not
        subhauler_id: { type: Schema.Types.ObjectId, default: null },
        type: { type: String, required: true },
        first_name: String,
        middle_name: String,
        last_name: String,
        emp_id: { type: Number, default: 0 },
        phone: String,
        street: String,
        city: String,
        state: String,
        zipcode: String,
        truck_type: String,
        emergency_phone: String,
        emerengcy_contact: String,
        medidcal_coverage: Date,
        license: String,
        license_pic: String,
        state_of_license: Number,
        pay_rate: Number,
        travel_time_rate: String,
        gender: String,
        hired_date: Date,
        dob: Date,
        street_health_care_offered: Date,
        license_expiry_date: Date,
        // puller specific fields 
        broker_fee: String,
        number_of_trucks_owned: Number,
        owner_name: String,
        notes: String,
        ssn: String,
        federal_id: String,
        device_token: String,
        mac_address: String,
        device_type: String,
        documents: []
    })
};

//creating models for collections
const models = {
    driverModel: mongoose.model('truckers', schemas.drivers),
}
module.exports = {
    schemas,
    models
};