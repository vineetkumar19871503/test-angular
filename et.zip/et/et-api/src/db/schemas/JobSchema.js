const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const types = ['H', 'T', 'L', 'B', 'D', 'O'],
    schemas = {
        jobs: new Schema({
            bill_from: { type: String, enum: ['amijot', 'economy'] },
            bill_minimum: Number,
            pay_minimum: Number,
            bill_type: { type: String, enum: types },
            c_id: { type: Schema.Types.ObjectId, required: true },
            certified_payroll: { type: String, enum: ['y', 'n'], allowNull: true },
            created_by: Schema.Types.ObjectId,
            created_date: { type: Date, default: Date.now },
            customer_id: { type: String, required: true, maxlength: 4 },    //id to show on UI
            deleted: { type: Boolean, default: false },
            destination: {
                address: String,
                lat: String,
                lng: String
            },
            direction: String,
            internal_notes: String,
            job_id: { type: String, required: true, maxlength: 4 },
            job_name: { type: String, required: true },
            modified_by: Schema.Types.ObjectId,
            modified_date: Date,
            origin: {
                address: String,
                lat: String,
                lng: String
            },
            pay_type: { type: String, enum: types },
            prelim_date: Date,
            request_dates1: Date,
            request_dates2: Date,
            request_dates3: Date,
            purchase_order: String,
            quote_id: { type: String, required: true },
            quarries: [
                {
                    quarry: String,
                    material: String,
                    we_buy: Number,
                    we_sell: Number,
                }
            ],
            qt_id: String,
            request_dates: [Date],
            truck_details: [
                {
                    truck_type: String,
                    bill_rate: String,
                    pay_rate: Number,
                    dump: Number,
                }
            ],
            document: Array,
            subjob_logs: [{
                'uid': { type: Schema.Types.ObjectId, required: true },
                'name': String,
                'internal_notes': String,
                'date': { type: Date, default: Date.now }
            }],
        }),
        sub_jobs: new Schema({
            bill_from: { type: String, enum: ['amijot', 'economy'] },
            bill_minimum: Number,
            pay_minimum: Number,
            bill_type: { type: String, enum: types },
            c_id: { type: Schema.Types.ObjectId, required: true },
            customer_id: { type: String, required: true, maxlength: 4 },    //id to show on UI
            certified_payroll: { type: String, enum: ['y', 'n'], default: 'n' },
            created_by: Schema.Types.ObjectId,
            created_date:{ type: Date, default: Date.now },
            deleted: { type: Boolean, default: false },
            destination: {
                address: String,
                lat: String,
                lng: String
            },
            direction: String,
            internal_notes: String,
            j_id: { type: Schema.Types.ObjectId, required: true },    //mongo id
            pjob_id: { type: String, required: true, maxlength: 4 },    // parent job id
            subjob_id: { type: String, required: true, maxlength: 4 },
            job_name: { type: String, required: true },
            modified_by: Schema.Types.ObjectId,
            modified_date: Date,
            origin: {
                address: String,
                lat: String,
                lng: String
            },
            pay_type: { type: String, enum: types },
            prelim_date: Date,
            request_dates1: Date,
            request_dates2: Date,
            request_dates3: Date,
            purchase_order: String,
            quarries: [
                {
                    quarry: String,
                    material: String,
                    we_buy: Number,
                    we_sell: Number,
                }
            ],
            request_dates: [Date],
            truck_details: [
                {
                    truck_type: String,
                    bill_rate: String,
                    pay_rate: Number,
                    dump: Number,
                    bill_bridge_toll_input: Number,
                    bill_dump_fee_input: Number,
                    bill_environmental_fee_input: Number,
                    pay_bridge_toll_input: Number,
                    pay_dump_fee_input: Number,
                    pay_environmental_fee_input: Number,
                    bill_others_input: Number,
                    pay_others_input: Number,
                    net_value: Number
                }
            ],
            bill_includes:Boolean,
            bill_bridge_toll_check:Boolean,
            bill_dump_fee_check:Boolean,
            bill_environmental_fee_check:Boolean,
            bill_others:String,
            bill_notApplicableCheck:Boolean,

            pay_includes:Boolean,
            pay_bridge_toll_check:Boolean,
            pay_dump_fee_check:Boolean,
            pay_environmental_fee_check:Boolean,
            pay_others:String,
            pay_notApplicableCheck:Boolean,
            
            document: Array,
            subjob_logs: [{
                'uid': { type: Schema.Types.ObjectId, required: true },
                'name': String,
                'internal_notes': String,
                'date': { type: Date, default: Date.now }
            }],
        })
    };

//creating models for collections
const models = {
    jobModel: mongoose.model('jobs', schemas.jobs),
    subJobModel: mongoose.model('sub_jobs', schemas.sub_jobs)
}

module.exports = {
    schemas,
    models
};