const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const types = ['H', 'T', 'L', 'B', 'D', 'O'],
    schemas = {
        bills: new Schema({
             created_date: Date,
              customer_id: String,
               customer_name: String,
                job_id: String,
                 job_name: String,
                  driver_id: String,
                   driver_name: String,
                    truck_type: String,
                     bill_from: String,
                 bill_type: String,
                  pay_type: String,
                   bill_minimum: String,
                    pay_minimum: String,
                     bill_total: Number,
                  pay_total: Number,
                   net: Number,
            bill_details: [
                {
                    pay_type: String,
                    quantity: String,
                    rate: Number,
                    tax: Number,
                     gross: Number,
                }
            ],
            pay_details: [
                {
                    pay_type: String,
                    quantity: String,
                    rate: Number,
                    tax: Number,
                     gross: Number,
                }
            ],
           
            status: String,
            converted: { type: Boolean, default: false },
            documents: []
        })
    };

//creating models for collections
const models = {
    quoteModel: mongoose.model('bills', schemas.bills)
}

module.exports = {
    schemas,
    models
};