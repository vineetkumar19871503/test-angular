const { getToday } = require('../../globals/methods');
mongoose = require('mongoose'),
    Schema = mongoose.Schema;
//defining schemas
const schemas = {
    dispatches: new Schema({
        job_id: { type: Schema.Types.ObjectId, required: true },
        date: { type: Date, default: getToday() },
        cancelled: { type: Boolean, default: false },
        cancelled_by: String,
        cancel_reason: String,
        cancel_date: { type: Date, default: getToday() }
    })
};

//creating models for collections
const models = {
    dispatchModel: mongoose.model('dispatches', schemas.dispatches)
}

module.exports = {
    schemas,
    models
};