const { getToday } = require('../../globals/methods'),
    mongoose = require('mongoose'),
    Schema = mongoose.Schema;


//defining schemas
const schemas = {
    assigned_jobs: new Schema({
        dispatch_id: { type: Schema.Types.ObjectId, required: true },
        // start_time: { type: Date, required: true },
        start_time: { type: Date, required: true },
        no_of_trucks: Number,
        interval: Number,
        truck_qty: [
            {
                truck_type: String,
                qty: Number
            }
        ],
        drivers: [
            {
                assigned_time: { type: Date, default: Date.now },
                driver_status: { type: String, default: 'o' },    // o- occupied
                cancelled: { type: Boolean, default: false },
                message_id: { type: String, default: null },
                comment: String,
                confirmed: { type: Boolean, default: false },
                driver_id: { type: Schema.Types.ObjectId, default: null },
                // driver_id: { type: Schema.Types.ObjectId, required: true },
                driver_type: String,
                time: { type: Date, required: false },
                // time: { type: Date, required: true },
                tag_id: { type: String, default: null },
                tag_id_status: { type: String, enum: ['active', 'completed', 'finished'], default: 'active' },
                tmp_tag_id: { type: String, default: null }
            }
        ]
    })
};

//creating models for collections
const models = {
    assignedJobModel: mongoose.model('assigned_jobs', schemas.assigned_jobs)
}

module.exports = {
    schemas,
    models
};