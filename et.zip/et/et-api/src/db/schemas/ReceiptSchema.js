const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
    const { getToday } = require('../../globals/methods');

//defining schemas
const schemas = {
    receipts: new Schema({
        tag_id: { type: String, default: null },
        job_id: { type: Schema.Types.ObjectId, required: true },
        image: { type: String, default: null },
        receipt_type: { type: String, default: null },
        other_receipt_type : { type: String, default: null },
        amount: { type: Number, default: null },
        status: { type: Boolean, default: true },
        created_date: { type: Date, default: getToday() }
    })
};

//creating models for collections
const models = {
    receiptModel: mongoose.model('receipts', schemas.receipts)
}

module.exports = {
    schemas,
    models
};