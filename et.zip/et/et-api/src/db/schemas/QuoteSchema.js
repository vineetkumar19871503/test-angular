const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const types = ['H', 'T', 'L', 'B', 'D', 'O'],
    schemas = {
        quotes: new Schema({
            c_id: { type: Schema.Types.ObjectId, required: true },    //mongo id
            deleted: { type: Boolean, default: false },
            quote_name: { type: String, required: true },
            bill_type: { type: String, enum: types },
            material: String,
            origin: {
                address: { type: String, default: null },
                lat: { type: String, default: null },
                lng: { type: String, default: null }
            },
            created_by: Schema.Types.ObjectId,
            created_date: Date,
            modified_by: Schema.Types.ObjectId,
            modified_date: Date,
            truck_details: [
                {
                    truck_type: String,
                    weekdays: String,
                    saturday: Number,
                    sunday: Number,
                }
            ],
            quantity: String,
            status: String,
            converted: { type: Boolean, default: false },
            documents: []
        })
    };

//creating models for collections
const models = {
    quoteModel: mongoose.model('quotes', schemas.quotes)
}

module.exports = {
    schemas,
    models
};