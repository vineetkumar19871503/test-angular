const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
    const { getToday } = require('../../globals/methods');

//defining schemas
const schemas = {
    trips: new Schema({
        trucker_id: { type: Schema.Types.ObjectId, required: true },
        tag_id: { type: String, default: null },
        job_id: { type: Schema.Types.ObjectId, required: true },
        status: {type:String,enum:['0','1','2'],default:'0'},
        loading_time_arrival:{ type: Date, default: null },
        loading_time_departure:{ type: Date, default: null },
        unloading_time_arrival:{ type: Date, default: null },
        unloading_time_departure:{ type: Date, default: null},
        is_driver_returning: { type: Boolean , default: false},
        created_date: { type: Date, default: getToday() }
    })
};

//creating models for collections
const models = {
    tripModel: mongoose.model('trips', schemas.trips)
}

module.exports = {
    schemas,
    models
};