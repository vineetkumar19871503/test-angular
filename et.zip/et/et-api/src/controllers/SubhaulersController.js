const authHandler = require('../handlers/AuthHandler'),
    driverModel = require('../db/models/DriverModel');
module.exports = {
    name: 'subhaulers',
    get: {
        index: function (req, res, next) {
            authHandler(req, res, next, function () {
                driverModel.getDrivers({ 'type': 'sh' })
                    .then(function (subhaulers) {
                        var response = { 
                            message: 'Subhaulers not found!'
                        };
                        if (subhaulers.length) {
                            response.message = 'Subhaulers';
                        }
                        response.data = subhaulers;
                        res.rest.success(response);
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            error: err.message
                        });
                    });
            });
        },
        getSubhaulersByTruckType: function (req, res, next) {
            authHandler(req, res, next, function () {
                const conditions = { 'drivers.type': 'sh' };
                let truckType;
                if (req.query.type && req.query.type != 'undefined') {
                    conditions['drivers.truck_type'] = truckType = req.query.type;
                }
                driverModel.getSubhaulers(conditions)
                    .then(function (subhaulers) {
                        let response = { message: 'Subhaulers not found!' };
                        if (subhaulers.length) {
                            if (truckType) {
                                // filtering subhauler drivers according to the truck type
                                // todo: need to remove this logic once proper filter is done from $lookup
                                subhaulers.forEach(function (sh, shi) {
                                    const shDrivers = [];
                                    if (sh.drivers.length) {
                                        sh.drivers.map(function (dr) {
                                            if (dr.truck_type === req.query.type) {
                                                shDrivers.push(dr);
                                            }
                                        });
                                    }
                                    subhaulers[shi].drivers = shDrivers;
                                });
                            }
                            response.message = 'Subhaulers';
                        }
                        response.data = subhaulers;
                        res.rest.success(response);
                    })
                    .catch(function (err) {
                        res.rest.serverError({ error: err.message });
                    });
            });
        },
        getUnoccupiedSubhaulersByTruckType: function (req, res, next) {
            authHandler(req, res, next, function () {
                const conditions = { 'drivers': { '$ne': [] }, 'drivers.type': 'sh' };
                if (req.query.type && req.query.type != 'undefined') {
                    conditions['drivers.truck_type'] = req.query.type;
                }
                driverModel.getUnoccupiedSubhaulers(conditions)
                    .then(function (subhaulers) {
                        let response = { message: 'Subhaulers not found!' };
                        if (subhaulers.length) {
                            response.message = 'Subhaulers';
                        }
                        response.data = subhaulers;
                        res.rest.success(response);
                    })
                    .catch(function (err) {
                        res.rest.serverError({ error: err.message });
                    });
            });
        }
    },
    post: {
        add: function (req, res, next) {
            authHandler(req, res, next, function () {
                driverModel.save(req.body)
                    .then(function (response) {
                        res.rest.success({
                            'message': 'Subhauler saved successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Subhauler could not be saved!!'
                        });
                    });
            });
        }
    }
}