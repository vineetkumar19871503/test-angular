const authHandler = require('../handlers/AuthHandler'),
    billModel = require('../db/models/BillModel'),
    ObjectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'bills',
    get: {
     
    },
    post: {
        add: function (req, res, next) {
            authHandler(req, res, next, function () {
                
                billModel.saveBill(req.body)
                    .then(function (dispatch) {
                        res.rest.success({
                            'data': dispatch,
                            'message': 'Bill saved successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Bill could not be saved! ' + err.message
                        });
                    });
            });
        }
    
    }
}